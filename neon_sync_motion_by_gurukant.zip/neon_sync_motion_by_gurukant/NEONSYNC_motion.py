import cv2
from cvzone.PoseModule import PoseDetector
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

# Setup
cap = cv2.VideoCapture(0)
detector = PoseDetector()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlim(-0.5, 0.5)
ax.set_ylim(-0.5, 0.5)
ax.set_zlim(-0.5, 0.5)
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# Define connections like mediapipe skeleton
connections = detector.mpPose.POSE_CONNECTIONS

while True:
    success, img = cap.read()
    if not success:
        break
    img = cv2.flip(img, 1)
    img = detector.findPose(img)
    lmList, bboxInfo = detector.findPosition(img, bboxWithHands=False)

    if lmList:
        ax.cla()  # Clear previous frame
        ax.set_xlim(-0.5, 0.5)
        ax.set_ylim(-0.5, 0.5)
        ax.set_zlim(-0.5, 0.5)

        # Convert 2D to normalized 3D points
        points3D = []
        for lm in lmList:
            x = lm[0]/640 - 0.5
            y = -(lm[1]/480 - 0.5)
            z = 0  # flat plane for now
            points3D.append((x, y, z))

        # Draw joints
        xs, ys, zs = zip(*points3D)
        ax.scatter(xs, ys, zs, c='cyan', s=50)

        # Draw connections
        for conn in connections:
            idx1, idx2 = conn
            if idx1 < len(points3D) and idx2 < len(points3D):
                x_line = [points3D[idx1][0], points3D[idx2][0]]
                y_line = [points3D[idx1][1], points3D[idx2][1]]
                z_line = [points3D[idx1][2], points3D[idx2][2]]
                ax.plot(x_line, y_line, z_line, c='magenta', linewidth=2)

    cv2.imshow("🟣 NeonSyncMotion - Webcam 🟡", img)
    plt.pause(0.001)  # small pause to update 3D plot

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
